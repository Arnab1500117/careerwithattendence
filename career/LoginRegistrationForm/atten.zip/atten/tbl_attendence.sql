-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2018 at 11:25 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kealcom_carrer`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendence`
--

CREATE TABLE `tbl_attendence` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `late_reason` varchar(20) NOT NULL,
  `original_time` time NOT NULL,
  `errand_place_in` varchar(20) NOT NULL,
  `errand_for_in` varchar(10) NOT NULL,
  `errand_from_in` time NOT NULL,
  `errand_to_in` time NOT NULL,
  `attendence_time` varchar(20) NOT NULL,
  `day` varchar(20) NOT NULL,
  `attendence_date` varchar(20) NOT NULL,
  `month` varchar(20) NOT NULL,
  `inip` varchar(255) NOT NULL,
  `early_leave` varchar(70) NOT NULL,
  `ongoing_works` text NOT NULL,
  `incase_errand_place` varchar(20) NOT NULL,
  `errand_for_out` varchar(25) NOT NULL,
  `errand_from_out` time NOT NULL,
  `errand_to_out` time NOT NULL,
  `outtime` varchar(20) NOT NULL,
  `outday` varchar(10) NOT NULL,
  `outmonth` varchar(20) NOT NULL,
  `outdate` varchar(20) NOT NULL,
  `ipOut` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_attendence`
--

INSERT INTO `tbl_attendence` (`id`, `userId`, `late_reason`, `original_time`, `errand_place_in`, `errand_for_in`, `errand_from_in`, `errand_to_in`, `attendence_time`, `day`, `attendence_date`, `month`, `inip`, `early_leave`, `ongoing_works`, `incase_errand_place`, `errand_for_out`, `errand_from_out`, `errand_to_out`, `outtime`, `outday`, `outmonth`, `outdate`, `ipOut`) VALUES
(1, 571, '', '00:00:00', '', '', '00:00:00', '00:00:00', '00:00:00', '', '', '', '', '', '', '', '', '00:00:00', '00:00:00', '', '', '', '', ''),
(2, 571, '', '08:58:00', '', '', '00:00:00', '00:00:00', '00:00:00', '', '', '', '', '', '', '', '', '00:00:00', '00:00:00', '', '', '', '', ''),
(3, 571, 'Select your Option', '00:00:00', '', '', '00:00:00', '00:00:00', '12:39:10', '(Tue)', '2018-01-30', 'Jan', '::1', '---', '', '', '', '00:00:00', '00:00:00', '15:24:29', '(Tue)', 'Jan', '2018-01-30', ''),
(4, 571, 'Select your Option', '00:00:00', '', '', '00:00:00', '00:00:00', '12:45:20', '(Tue)', '2018-01-30', 'Jan', '::1', '---', '', '', '', '00:00:00', '00:00:00', '15:24:29', '(Tue)', 'Jan', '2018-01-30', ''),
(5, 571, 'Select your Option', '00:00:00', '', '', '00:00:00', '00:00:00', '12:46:30', '(Tue)', '2018-01-30', 'Jan', '::1', '---', '', '', '', '00:00:00', '00:00:00', '15:24:29', '(Tue)', 'Jan', '2018-01-30', ''),
(6, 571, 'Select your Option', '00:00:00', '', '', '00:00:00', '00:00:00', '12:48:17', '(Tue)', '2018-01-30', 'Jan', '::1', '---', '', '', '', '00:00:00', '00:00:00', '15:24:29', '(Tue)', 'Jan', '2018-01-30', ''),
(7, 571, 'Select your Option', '00:00:00', '', '', '00:00:00', '00:00:00', '12:49:00', '(Tue)', '2018-01-30', 'Jan', '::1', '---', '', '', '', '00:00:00', '00:00:00', '15:24:29', '(Tue)', 'Jan', '2018-01-30', ''),
(8, 571, '---', '00:00:00', '', '', '00:00:00', '00:00:00', '13:05:06', '(Tue)', '2018-01-30', 'Jan', '::1', '---', '', '', '', '00:00:00', '00:00:00', '15:24:29', '(Tue)', 'Jan', '2018-01-30', ''),
(9, 571, '---', '00:00:00', '', '', '00:00:00', '00:00:00', '13:47:45', '(Tue)', '2018-01-30', 'Jan', '::1', '---', '', '', '', '00:00:00', '00:00:00', '15:24:29', '(Tue)', 'Jan', '2018-01-30', ''),
(10, 571, '---', '00:00:00', '', '', '00:00:00', '00:00:00', '15:24:34', '(Tue)', '2018-01-30', 'Jan', '::1', '', '', '', '', '00:00:00', '00:00:00', '', '', '', '', ''),
(11, 571, '---', '00:00:00', '', '', '00:00:00', '00:00:00', '16:17:52', '(Tue)', '2018-01-30', 'Jan', '::1', '', '', '', '', '00:00:00', '00:00:00', '', '', '', '', ''),
(12, 571, '---', '00:00:00', '', '', '00:00:00', '00:00:00', '16:20:47', '(Tue)', '2018-01-30', 'Jan', '::1', '', '', '', '', '00:00:00', '00:00:00', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_attendence`
--
ALTER TABLE `tbl_attendence`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_attendence`
--
ALTER TABLE `tbl_attendence`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
