	  <?php include 'inc/header.php' ?>

	<section id="content">
	<div class="container">
	<h1> GIVE YOUR ATTENDANCE</h1>
			<div class="row">
			
		<div class="skill-home"> <div class="skill-home-solid clearfix"> 
					<div class="row">
			<div class="col-md-12 text-center">
				<a href="I_am_in.php?userId = <?php echo $userId;?>"><button type="button" class="btn btn-lg btn-primary">I AM In</button></a>
			</div>

			</div> 
			<div class="row">
				<div class="col-md-12 text-center">
					<a href="I_am_out.php?userId = <?php echo $userId;?>"><button type="button" class="btn btn-lg btn-primary">I AM Out</button></a>
				</div>
			</div>
		
		
		</div> </div>
		</div> 
	 

	</div></section>
		  <?php include 'inc/footer.php' ?>