<?php include 'inc/header.php'; ?>
	<!-- end header -->
<?php include 'inc/banner.php'; ?>

<?php include 'inc/callaction.php'; ?>

<?php include 'inc/content.php'; ?>

<?php include 'inc/about_us.php'; ?>	
<?php include 'inc/events.php'; ?>
	
<?php include 'inc/clients.php'; ?>	
<?php include 'inc/testimonial.php'; ?>	
<?php include 'inc/footer.php'; ?>	
	
	
	
	
	
