	<section class="callaction">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="aligncenter"><h1 class="aligncenter">Kyoto Engineering & Automation Ltd</h1></div>
				
			</div>
		</div>
	</div>
	</section>