<section id='events'>
	<div class="container">
	<div class="row">
			<div class="col-md-12">
				<div class="aligncenter"><h2 class="aligncenter">Our Events</h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores quae porro consequatur aliquam, incidunt eius magni provident, doloribus omnis minus temporibus perferendis nesciunt quam repellendus nulla nemo ipsum odit corrupti consequuntur possimus.</div>
				<br>
			</div>
		</div>
	<div class="row">
                <div class="col-md-4">
                    <div class="post3">
                        <img src="img/e1.png" alt="">
                        <a href="#">
                            <time datetime="2015-03-01">
                                <span class="year">2015</span>
                                <span class="month">Feb</span>
                            </time>
                            <p>Lorem ipsum dolor sit amet, consectetur adipis.</p>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="post3">
                        <img src="img/e2.png" alt="">
                        <a href="#">
                            <time datetime="2015-03-01">
                                <span class="year">2015</span>
                                <span class="month">March</span>
                            </time>
                            <p>Apsum dolor sit amet, consectetur adipisdslif.</p>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="post3">
                        <img src="img/e3.png" alt="">
                        <a href="#">
                            <time datetime="2015-03-01">
                                <span class="year">2015</span>
                                <span class="month">April</span>
                            </time>
                            <p>Dolor sit amet, consectetur adipisic indfeft</p>
                        </a>
                    </div>
                </div>
            </div>
	</div>
	</section>