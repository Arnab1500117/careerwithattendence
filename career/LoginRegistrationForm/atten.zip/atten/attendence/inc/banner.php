	<section id="banner">
	 
	<!-- Slider -->
        <div id="main-slider" class="flexslider">
            <ul class="slides">
              <li>
                <img src="img/slides/1.jpg" alt="" />
                <div class="flex-caption container">
                    <h3></h3> 
					<p><br/> </p> 
					<!--<a href="#" class="btn btn-theme">Read More</a> -->
                </div>
              </li>
              <li>
                <img src="img/slides/2.jpg" alt="" />
                <div class="flex-caption container">
                    <h3></h3> 
					<p><br/> </p> 
					<!--<a href="#" class="btn btn-theme">Read More</a> -->
                </div>
              </li>
            </ul>
        </div>
	<!-- end slider -->
 
	</section>