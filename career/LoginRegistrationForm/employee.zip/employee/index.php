<?php include "inc/header.php";?>

<?php include "inc/head.php";?>

<!-- career objective -->
<?php include "inc/career.php";?>

<!-- education section -->
<?php include "inc/education.php";?>

<!-- work experience -->
<?php //include "inc/work.php";?>

<!-- professional training -->
<?php //include "inc/professional.php";?>

<!-- skills -->
<?php //include "inc/skill.php";?>

<!-- language -->
<?php //include "inc/language.php";?>

<!-- personal -->
<?php //include "inc/personal.php";?>





<!-- footer -->
<?php include "inc/footer.php";?>