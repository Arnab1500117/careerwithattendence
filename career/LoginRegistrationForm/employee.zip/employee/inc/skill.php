			<section>
				<div class="sectionTitle">
					<h1>Skills</h1>
				</div>

				<div class="sectionContent">
					<ul class="keySkills">
						<li>HTML</li>
						<li>CSS</li>
						<li>Bootstrap</li>
						<li>Javascript</li>
						<li>MySQL</li>
						<li>PHP</li>
					</ul>
				</div>
				<div class="clear"></div>
			</section>